import React from 'react';
import type { Region, RegionInfo } from '../types';

interface RegionFilterProps {
  regions: RegionInfo[];
  selectedRegion: Region | 'all';
  onSelect: (region: Region | 'all') => void;
}

const RegionFilter: React.FC<RegionFilterProps> = ({ regions, selectedRegion, onSelect }) => {
  return (
    <div className="mb-4 bg-white/60 dark:bg-stone-800/60 backdrop-blur-sm p-4 rounded-xl max-w-2xl mx-auto shadow-sm border border-white/50">
      <p className="text-center font-semibold text-stone-700 dark:text-stone-300 mb-3 text-sm">
        ಒಂದು ಪ್ರದೇಶವನ್ನು ಆಯ್ಕೆಮಾಡಿ ಅಥವಾ ಎಲ್ಲವನ್ನೂ ಅನ್ವೇಷಿಸಿ
      </p>
      <div className="flex justify-center flex-wrap gap-3">
        {regions.map((region) => {
          const isSelected = selectedRegion === region.key;
          return (
            <button
              key={region.key}
              onClick={() => onSelect(region.key)}
              aria-pressed={isSelected}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-red-700 focus:ring-offset-2 focus:ring-offset-white/80
                ${
                  isSelected
                    ? 'bg-red-800 text-white border-red-800 shadow-md scale-105'
                    : 'bg-white/80 text-stone-800 border-stone-300 hover:bg-stone-50 hover:border-stone-400'
                }
              `}
            >
              <span className="text-lg">{region.emoji}</span>
              <span>{region.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default RegionFilter;


import React from 'react';

interface SuggestionChipsProps {
  suggestions: string[];
  onSelect: (suggestion: string) => void;
}

const SuggestionChips: React.FC<SuggestionChipsProps> = ({ suggestions, onSelect }) => {
  return (
    <div className="flex justify-center flex-wrap gap-2 max-w-2xl mx-auto my-2">
      {suggestions.map((suggestion) => (
        <button
          key={suggestion}
          onClick={() => onSelect(suggestion)}
          className="bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-200 border border-stone-300/80 dark:border-stone-600/80 rounded-full px-4 py-1.5 text-sm font-medium hover:bg-stone-200 dark:hover:bg-stone-700 focus:outline-none focus:ring-2 focus:ring-red-800 focus:ring-offset-1 transition-colors"
        >
          {suggestion}
        </button>
      ))}
    </div>
  );
};

export default SuggestionChips;

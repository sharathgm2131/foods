
import React from 'react';
import { UtensilsCrossed, Send } from 'lucide-react';

interface FrontPageProps {
  onEnter: () => void;
}

const content = {
  title: "ಕರುನಾಡು ಆಹಾರ",
  subtitle: "ಕರ್ನಾಟಕದ ಪಾಕಶಾಲೆಯ ರಹಸ್ಯಗಳನ್ನು ಅನ್ವೇಷಿಸಿ",
  buttonText: "ಪ್ರಾರಂಭಿಸಿ",
};

const FrontPage: React.FC<FrontPageProps> = ({ onEnter }) => {
  const { title, subtitle, buttonText } = content;
  
  return (
    <div className="relative flex flex-col items-center justify-center h-full text-white p-8 text-center overflow-hidden">
      
      <div className="z-10 flex flex-col items-center">
        <div className="bg-white/20 rounded-full p-6 mb-6 shadow-lg animate-fade-in-scale backdrop-blur-sm" style={{ animationDelay: '100ms' }}>
          <UtensilsCrossed className="w-16 h-16 text-white" />
        </div>
        <h1 className="text-5xl md:text-7xl font-bold mb-4 font-kannada animate-fade-in-up" style={{ textShadow: '2px 2px 8px rgba(0,0,0,0.6)', animationDelay: '300ms' }}>
          {title}
        </h1>
        <p className="text-lg md:text-xl mb-12 animate-fade-in-up" style={{ textShadow: '1px 1px 4px rgba(0,0,0,0.6)', animationDelay: '500ms' }}>
            {subtitle}
        </p>
        <button
          onClick={onEnter}
          className="bg-yellow-500 text-red-900 font-bold py-4 px-10 rounded-full text-xl hover:bg-yellow-400 transition-all transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-yellow-500/50 flex items-center gap-3 shadow-xl animate-fade-in-up"
          style={{ animationDelay: '700ms' }}
        >
          <Send className="w-6 h-6" />
          <span>{buttonText}</span>
        </button>
      </div>
    </div>
  );
};

export default FrontPage;


import React from 'react';
import type { Message } from '../types';
import { User, Bot } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isBot = message.sender === 'bot';

  const wrapperClasses = `flex items-start gap-3 w-full max-w-2xl mx-auto ${isBot ? '' : 'flex-row-reverse'}`;
  const messageBoxClasses = `px-4 py-3 rounded-2xl shadow-sm ${
    isBot
      ? 'bg-white dark:bg-stone-700 text-stone-800 dark:text-stone-200 rounded-tl-none border border-stone-200 dark:border-stone-600'
      : 'bg-teal-700 dark:bg-teal-800 text-white rounded-tr-none'
  }`;
  
  const Icon = isBot ? Bot : User;
  const iconWrapperClasses = `w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${
    isBot ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-300' : 'bg-teal-100 dark:bg-teal-900 text-teal-800 dark:text-teal-300'
  }`;

  return (
    <div className={wrapperClasses}>
      <div className={iconWrapperClasses}>
        <Icon className="w-5 h-5" />
      </div>
      <div className={messageBoxClasses}>
        {message.imageUrl && (
            <img 
                src={message.imageUrl} 
                alt="ಖಾದ್ಯದ ಚಿತ್ರ" 
                className="w-full h-auto max-h-64 object-cover rounded-lg mb-3 shadow"
            />
        )}
        <p className="text-sm whitespace-pre-wrap">{message.text}</p>
      </div>
    </div>
  );
};

export default ChatMessage;

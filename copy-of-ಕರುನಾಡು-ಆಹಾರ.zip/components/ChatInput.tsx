
import React, { useState } from 'react';
import { SendHorizontal, LoaderCircle } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [text, setText] = useState('');
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isLoading) {
      onSendMessage(text);
      setText('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as unknown as React.FormEvent);
    }
  };

  const placeholderText = "ಕರುನಾಡಿನ ಆಹಾರದ ಬಗ್ಗೆ ಕೇಳಿ...";

  return (
    <form onSubmit={handleSubmit} className="flex items-start space-x-2">
      <div className="flex-1 relative">
        <textarea
          ref={textareaRef}
          value={text}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholderText}
          className="w-full p-3 pr-12 border border-stone-300 dark:border-stone-600 rounded-lg focus:ring-2 focus:ring-red-800 focus:outline-none bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 resize-none"
          rows={1}
          style={{ maxHeight: '150px' }}
          disabled={isLoading}
        />
      </div>
      <button
        type="submit"
        disabled={isLoading || !text.trim()}
        className="h-12 w-12 flex-shrink-0 bg-red-800 text-white rounded-full flex items-center justify-center hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-800 focus:ring-offset-2 disabled:bg-red-300 disabled:cursor-not-allowed transition-colors"
      >
        {isLoading ? <LoaderCircle className="w-5 h-5 animate-spin" /> : <SendHorizontal className="w-5 h-5" />}
      </button>
    </form>
  );
};

// Simplified stand-ins for lucide-react icons for illustration
const LucideIcon: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    {children}
  </svg>
);

const SendHorizontalIcon: React.FC<{ className?: string }> = ({ className }) => (
    <LucideIcon className={className}>
        <path d="m3 3 3 9-3 9 19-9Z"/>
        <path d="M6 12h16"/>
    </LucideIcon>
);

const LoaderCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <LucideIcon className={className}>
        <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
    </LucideIcon>
);

export default ChatInput;

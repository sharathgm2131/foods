export type Sender = 'user' | 'bot';

export interface Message {
  id: number;
  text: string;
  sender: Sender;
  imageUrl?: string;
}

export type Region = 'north' | 'south' | 'coastal';

export interface RegionInfo {
  key: Region | 'all';
  name: string;
  emoji: string;
}

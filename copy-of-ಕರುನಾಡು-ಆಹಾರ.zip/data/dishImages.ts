export const dishImageMap: { keywords: string[]; url: string }[] = [
  {
    keywords: ['mangaluru buns', 'mangalore buns', 'ಮಂಗಳೂರು ಬನ್ಸ್'],
    url: 'https://upload.wikimedia.org/wikipedia/commons/c/ca/Mangalore_Buns.jpg',
  },
  {
    keywords: ['dharwad peda', 'ಧಾರವಾಡ ಪೇಡ'],
    url: 'https://upload.wikimedia.org/wikipedia/commons/8/87/Dharwad_pedha.jpg',
  },
  {
    keywords: ['kodagina pandi curry', 'pandi curry', 'ಕೊಡಗಿನ ಪಂದಿ ಕರಿ', 'ಪಂದಿ ಕರಿ'],
    url: 'https://www.archanaskitchen.com/images/archanaskitchen/1-Author/Waagmi-Soni/Coorgi_Pandi_Curry__Coorg_Style_Pork_Curry.jpg',
  },
  {
    keywords: ['kesari bath', 'ಕೇಸರಿ ಬಾತ್'],
    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Rava_Kesari.jpg/1280px-Rava_Kesari.jpg',
  },
  {
    keywords: ['maddur vada', 'ಮದ್ದೂರು ವಡೆ'],
    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Maddur_vada.JPG/1024px-Maddur_vada.JPG',
  },
  {
    keywords: ['bisi bele bath', 'ಬಿಸಿ ಬೇಳೆ ಬಾತ್'],
    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Bisi_Bele_Bath.JPG/1280px-Bisi_Bele_Bath.JPG',
  },
  {
    keywords: ['mysore pak', 'ಮೈಸೂರು ಪಾಕ್'],
    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Mysore_pak_in_a_shop.jpg/1280px-Mysore_pak_in_a_shop.jpg',
  },
  {
      keywords: ['jolada rotti', 'jowar roti', 'ಜೋಳದ ರೊಟ್ಟಿ'],
      url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Jolada_rotti_oota.jpg/1280px-Jolada_rotti_oota.jpg'
  },
  {
      keywords: ['ragi mudde', 'ರಾಗಿ ಮುದ್ದೆ'],
      url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/Ragi_mudde_with_soppina_saaru.jpg/1280px-Ragi_mudde_with_soppina_saaru.jpg'
  }
];

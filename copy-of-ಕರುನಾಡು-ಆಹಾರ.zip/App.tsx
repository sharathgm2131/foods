
import React, { useState, useEffect, useRef } from 'react';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import LoadingIndicator from './components/LoadingIndicator';
import SuggestionChips from './components/SuggestionChips';
import FrontPage from './components/FrontPage';
import RegionFilter from './components/RegionFilter';
import { getBotResponse, createChat } from './services/geminiService';
import type { Message, Region, RegionInfo } from './types';
import { UtensilsCrossed, Mail, Search } from 'lucide-react';
import type { Chat } from '@google/genai';

// Helper function to load messages from localStorage
const loadMessagesFromStorage = (): Message[] => {
  try {
    const savedMessages = localStorage.getItem('chatHistory');
    if (savedMessages) {
      const parsedMessages = JSON.parse(savedMessages);
      if (Array.isArray(parsedMessages)) {
        return parsedMessages;
      }
    }
  } catch (error) {
    console.error('Failed to load messages from localStorage:', error);
  }
  return [];
};

const regions: RegionInfo[] = [
  { key: 'all', name: 'ಎಲ್ಲಾ ಪ್ರದೇಶಗಳು', emoji: '🗺️' },
  { key: 'north', name: 'ಉತ್ತರ ಕರ್ನಾಟಕ', emoji: '🌾' },
  { key: 'south', name: 'ದಕ್ಷಿಣ ಕರ್ನಾಟಕ', emoji: '🏛️' },
  { key: 'coastal', name: 'ಕರಾವಳಿ', emoji: '🥥' },
];

const getSuggestionsForRegion = (region: Region | 'all') => {
    switch(region) {
      case 'north':
        return ['ಜೋಳದ ರೊಟ್ಟಿ ಮಾಡುವುದು ಹೇಗೆ?', 'ಎಣ್ಣೆಗಾಯಿ ಪಾಕವಿಧಾನ', 'ಶೇಂಗಾ ಚಟ್ನಿಪುಡಿ'];
      case 'south':
        return ['ರಾಗಿ ಮುದ್ದೆ ಮತ್ತು ಸೊಪ್ಪಿನ ಸಾರು', 'ಮೈಸೂರು ಪಾಕ್ ರೆಸಿಪಿ', 'ಮಸಾಲೆ ದೋಸೆ ವಿಶೇಷತೆ'];
      case 'coastal':
        return ['ನೀರ್ ದೋಸೆ ಎಂದರೇನು?', 'ಕೋರಿ ರೊಟ್ಟಿ', 'ಮಂಗಳೂರು ಮೀನಿನ ಮೇಲೋಗರ'];
      case 'all':
      default:
        return ["ಬಿಸಿ ಬೇಳೆ ಬಾತ್ ಎಂದರೇನು?", "ಮೈಸೂರು ಪಾಕ್ ರೆಸಿಪಿ", "ಅಕ್ಕಿ ಮತ್ತು ಬೇಳೆಯಿಂದ ಏನು ಮಾಡಬಹುದು?"];
    }
}

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>(loadMessagesFromStorage);
  const [isLoading, setIsLoading] = useState(false);
  const [showFrontPage, setShowFrontPage] = useState(messages.length === 0);
  const [selectedRegion, setSelectedRegion] = useState<Region | 'all'>('all');
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (messages.length > 0) {
      localStorage.setItem('chatHistory', JSON.stringify(messages));
    } else {
      localStorage.removeItem('chatHistory');
    }
  }, [messages]);
  
  const startChat = () => {
    chatRef.current = createChat(null);
    setShowFrontPage(false);
  };

  const handleNewChat = () => {
    setMessages([]); 
    setSelectedRegion('all');
    chatRef.current = createChat(null);
  };
  
  const handleRegionSelect = (regionKey: Region | 'all') => {
    if (regionKey === selectedRegion) return;
    
    setMessages([]); // Clear previous conversation
    setSelectedRegion(regionKey);
    // Re-create the chat instance with the new context. 
    chatRef.current = createChat(regionKey === 'all' ? null : regionKey);
  };

  const handleSendMessage = async (text: string) => {
    if (isLoading) return;

    const userMessage: Message = { id: Date.now(), text, sender: 'user' };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    if (!chatRef.current) {
        chatRef.current = createChat(selectedRegion === 'all' ? null : selectedRegion);
    }

    try {
      const { text: botResponseText, imageUrl } = await getBotResponse(chatRef.current, text);

      const botMessage: Message = {
        id: Date.now() + 1,
        text: botResponseText,
        sender: 'bot',
        imageUrl: imageUrl || undefined,
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Failed to get response:", error);
      const errorMessage: Message = {
        id: Date.now() + 1,
        text: "ಕ್ಷಮಿಸಿ, ನಿಮ್ಮ ವಿನಂತಿಯನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲು ನನಗೆ ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
        sender: 'bot',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const mailtoHref = `mailto:feedback-karunadu-foods@example.com?subject=${encodeURIComponent(
    "ಕರುನಾಡು ಆಹಾರ ಅಪ್ಲಿಕೇಶನ್‌ಗೆ ಪ್ರತಿಕ್ರಿಯೆ"
  )}&body=${encodeURIComponent(
    "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯೆಯನ್ನು ಇಲ್ಲಿ ಹಂಚಿಕೊಳ್ಳಿ:\n\n"
  )}`;

  const backgroundStyle: React.CSSProperties = {
    background: 'linear-gradient(to bottom, #FFC300, #C70039)',
    backgroundAttachment: 'fixed'
  };

  if (showFrontPage) {
    return (
      <div className="w-full h-screen" style={backgroundStyle}>
        <FrontPage onEnter={startChat} />
      </div>
    );
  }

  const currentSuggestions = getSuggestionsForRegion(selectedRegion);

  return (
    <div className="flex flex-col h-screen font-sans text-stone-800" style={backgroundStyle}>
      <header className="bg-white/80 dark:bg-stone-900/80 backdrop-blur-sm p-4 flex justify-between items-center z-10 border-b border-stone-200 dark:border-stone-700">
        <div className="flex-1 flex justify-start">
            <div className="flex items-center gap-3">
            <UtensilsCrossed className="w-8 h-8 text-red-800" />
            <h1 className="text-xl font-bold text-stone-800 dark:text-stone-200">
                ಕರುನಾಡು ಆಹಾರ ಎಕ್ಸ್‌ಪ್ಲೋರರ್
            </h1>
            </div>
        </div>
        <div className="flex-1 flex justify-center">
            <button
              onClick={handleNewChat}
              title="ಹೊಸ ಚಾಟ್ ಪ್ರಾರಂಭಿಸಿ"
              aria-label="Start new chat"
              className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-stone-700 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-lg hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors focus:outline-none focus:ring-2 focus:ring-red-700"
            >
              <Search className="w-4 h-4" />
              <span>ಹೊಸ ಹುಡುಕಾಟ</span>
            </button>
        </div>
        <div className="flex-1 flex justify-end">
            <a
            href={mailtoHref}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-stone-700 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-lg hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors focus:outline-none focus:ring-2 focus:ring-red-700"
            >
            <Mail className="w-4 h-4" />
            <span>ಪ್ರತಿಕ್ರಿಯೆ ಕಳುಹಿಸಿ</span>
            </a>
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <RegionFilter 
            regions={regions} 
            selectedRegion={selectedRegion}
            onSelect={handleRegionSelect}
        />
        <div className="space-y-6 mt-4">
            {messages.length === 0 && !isLoading && (
                <div className="text-center text-stone-600 dark:text-stone-400 mt-8 bg-white/50 backdrop-blur-sm p-4 rounded-lg max-w-md mx-auto">
                    <p className="font-semibold text-stone-800 dark:text-stone-200">
                        ಮೇಲಿನಿಂದ ಒಂದು ಪ್ರದೇಶವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ ಅಥವಾ ನೇರವಾಗಿ ಪ್ರಶ್ನೆಯನ್ನು ಕೇಳಿ!
                    </p>
                </div>
            )}
            {messages.map((msg) => (
              <ChatMessage key={msg.id} message={msg} />
            ))}
            {isLoading && <LoadingIndicator />}
            <div ref={messagesEndRef} />
        </div>
      </main>

      <footer className="bg-white/80 dark:bg-stone-900/80 backdrop-blur-sm p-4 border-t border-stone-200 dark:border-stone-700">
        {messages.length === 0 && (
          <SuggestionChips
            suggestions={currentSuggestions}
            onSelect={handleSendMessage}
          />
        )}
        <div className="max-w-2xl mx-auto">
          <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        </div>
      </footer>
    </div>
  );
};

export default App;

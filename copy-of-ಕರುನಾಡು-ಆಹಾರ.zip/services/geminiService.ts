import { GoogleGenAI, Chat, Modality } from "@google/genai";
import { dishImageMap } from '../data/dishImages';
import type { Region } from '../types';

// Per guidelines, get API key from environment variables
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const model = 'gemini-2.5-flash';

const baseSystemInstruction = `ನೀವು ಕರ್ನಾಟಕದ ಪಾಕಪದ್ಧತಿಯಲ್ಲಿ ಪರಿಣತರು. ನಿಮ್ಮ ಹೆಸರು ಕರುನಾಡು ರುಚಿಗಳು.
- ಸಂಕ್ಷಿಪ್ತ ಮತ್ತು ಸಹಾಯಕವಾದ ಉತ್ತರಗಳನ್ನು ನೀಡಿ.
- ಪಾಕವಿಧಾನವನ್ನು ಕೇಳಿದಾಗ, ಅದನ್ನು ಸ್ಪಷ್ಟ, ಹಂತ-ಹಂತದ ಸ್ವರೂಪದಲ್ಲಿ ನೀಡಿ.
- ಪಾಕವಿಧಾನವನ್ನು ನೀಡುವಾಗ, ಅದರ ಕಷ್ಟದ ಮಟ್ಟ (ಸುಲಭ, ಮಧ್ಯಮ, ಕಠಿಣ) ಮತ್ತು ಅಂದಾಜು ತಯಾರಿಕೆಯ/ಅಡುಗೆ ಸಮಯವನ್ನು ಸೇರಿಸಿ.
- ನಿರ್ದಿಷ್ಟ ಖಾದ್ಯದ ಬಗ್ಗೆ ಮಾಹಿತಿ ನೀಡುವಾಗ, ನಿಮ್ಮ ಪ್ರತ್ಯುತ್ತರದ ಕೊನೆಯಲ್ಲಿ "IMAGETOPIC:[Dish Name in English]" ಎಂಬ ವಿಶೇಷ ಟೋಕನ್ ಸೇರಿಸಿ. ಉದಾಹರಣೆಗೆ, ಬಿಸಿ ಬೇಳೆ ಬಾತ್ ಬಗ್ಗೆ ವಿವರಿಸಿದ ನಂತರ, "IMAGETOPIC:[Bisi Bele Bath]" ಎಂದು ಸೇರಿಸಿ. ಇದು ನಿರ್ದಿಷ್ಟ ಖಾದ್ಯವಲ್ಲದಿದ್ದರೆ ಈ ಟೋಕನ್ ಅನ್ನು ಸೇರಿಸಬೇಡಿ.
- ಯಾವಾಗಲೂ ಕನ್ನಡದಲ್ಲಿ ಉತ್ತರಿಸಿ.`;

const regionInstructions: Record<Region, string> = {
  north: 'ನೀವು ಉತ್ತರ ಕರ್ನಾಟಕದ ಪಾಕಪದ್ಧತಿಯ ಮೇಲೆ ವಿಶೇಷ ಗಮನ ಹರಿಸುತ್ತೀರಿ, ಉದಾಹರಣೆಗೆ ಜೋಳದ ರೊಟ್ಟಿ, ಎಣ್ಣೆಗಾಯಿ, ಶೇಂಗಾ ಚಟ್ನಿಪುಡಿ.',
  south: 'ನೀವು ದಕ್ಷಿಣ ಕರ್ನಾಟಕದ (ಮೈಸೂರು/ಬೆಂಗಳೂರು) ಪಾಕಪದ್ಧತಿಯ ಮೇಲೆ ವಿಶೇಷ ಗಮನ ಹರಿಸುತ್ತೀರಿ, ಉದಾಹರಣೆಗೆ ರಾಗಿ ಮುದ್ದೆ, ಬಿಸಿ ಬೇಳೆ ಬಾತ್, ಮೈಸೂರು ಪಾಕ್.',
  coastal: 'ನೀವು ಕರಾವಳಿ ಕರ್ನಾಟಕದ (ಮಂಗಳೂರು/ಉಡುಪಿ) ಪಾಕಪದ್ಧತಿಯ ಮೇಲೆ ವಿಶೇಷ ಗಮನ ಹರಿಸುತ್ತೀರಿ, ಉದಾಹರಣೆಗೆ ನೀರ್ ದೋಸೆ, ಕೋರಿ ರೊಟ್ಟಿ, ಮೀನಿನ ಖಾದ್ಯಗಳು.',
};

export const createChat = (region: Region | null): Chat => {
  let systemInstruction = baseSystemInstruction;
  if (region && regionInstructions[region]) {
    systemInstruction += `\n\n${regionInstructions[region]}`;
  }

  return ai.chats.create({
    model: model,
    config: {
      systemInstruction: systemInstruction,
    },
  });
};

async function generateDishImage(dishName: string): Promise<string | null> {
  try {
    const prompt = `A high-quality, appetizing photo of ${dishName}, a popular dish from Karnataka, India. The dish should be the main focus, presented beautifully.`;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: { responseModalities: [Modality.IMAGE] },
    });

    const firstPart = response.candidates?.[0]?.content?.parts?.[0];
    if (firstPart && firstPart.inlineData) {
      const base64ImageBytes = firstPart.inlineData.data;
      return `data:image/png;base64,${base64ImageBytes}`;
    }
    console.warn(`No image data received for ${dishName}.`);
    return null;
  } catch (error) {
    console.error(`Error generating image for ${dishName}:`, error);
    return null;
  }
}


export const getBotResponse = async (chat: Chat, message: string): Promise<{ text: string; imageUrl: string | null; }> => {
  try {
    const result = await chat.sendMessage({ message });
    let responseText = result.text;
    let imageUrl: string | null = null;
    
    const imageTopicMatch = responseText.match(/IMAGETOPIC:\[(.*?)\]/);

    if (imageTopicMatch && imageTopicMatch[1]) {
      const dishName = imageTopicMatch[1].trim();
      responseText = responseText.replace(/IMAGETOPIC:\[.*?\]/, '').trim();

      const dishNameLower = dishName.toLowerCase();
      const existingImage = dishImageMap.find(dish => 
          dish.keywords.some(kw => dishNameLower.includes(kw.toLowerCase()))
      );

      if (existingImage) {
        imageUrl = existingImage.url;
      } else {
        imageUrl = await generateDishImage(dishName);
      }
    }

    return { text: responseText, imageUrl };

  } catch (error) {
    console.error("Error getting bot response:", error);
    const errorText = "ಕ್ಷಮಿಸಿ, ನನ್ನ ಜ್ಞಾನದ ಮೂಲಕ್ಕೆ ಸಂಪರ್ಕಿಸಲು ನನಗೆ ತೊಂದರೆಯಾಗುತ್ತಿದೆ. ದಯವಿಟ್ಟು ನಂತರ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.";
    return { text: errorText, imageUrl: null };
  }
};
